import { Controller, Get, Post, Body, Query } from '@nestjs/common';
import { AppService } from './app.service';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  // 1. Rota padrão (apenas para teste)
  @Get()
  getHello(): string {
    return this.appService.getHello();
  }

  // 2. POST /pratica - Cadastrar nova prática [cite: 31, 32]
  @Post('pratica')
  cadastrarPratica(@Body() body: { nomeUsuario: string; tipo: string; data: string; descricao?: string }) {
    // Como o banco está desligado, apenas simulamos o sucesso [cite: 33, 34, 35, 36, 37]
    console.log('Dados recebidos:', body);
    return { message: 'Prática cadastrada com sucesso (Simulado)!', dados: body };
  }

  // 3. GET /historico - Listar práticas [cite: 38, 39]
  @Get('historico')
  getHistorico(@Query() query: any) {
    // Retorna uma lista vazia para não dar erro 404 [cite: 26]
    return [];
  }

  // 4. GET /estatisticas - Resumo consolidado [cite: 44, 45]
  @Get('estatisticas')
  getEstatisticas() {
    return {
      tipoMaisRegistrado: "Nenhum",
      usuarioMaisAtivo: "Nenhum",
      totalPorTipo: {},
      totalGeral: 0,
      mediaDiaria: 0
    };
  }
}