import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';

@Module({
  imports: [], // Mantenha o MongooseModule comentado aqui
  controllers: [AppController], // Apenas o AppController já resolve tudo
  providers: [AppService],
})
export class AppModule {}